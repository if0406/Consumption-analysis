
# coding: utf-8

# In[3]:


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
frame= pd.read_table("task2-X1.csv", sep = ',',encoding = 'gbk')
def XIUXI(a):
    fei=[5,6,7,13,14,20,21,29,30]
    return a in fei
def GONGZUO(a):
    fei=[5,6,7,13,14,20,21,29,30]
    return a not in fei          #自定义函数划分工作日和非工作日
feigong=frame.loc[frame['day'].apply(XIUXI)]
gongzuori=frame.loc[frame['day'].apply(GONGZUO)]
t=[]
plt.rcParams['font.sans-serif']='SimHei'   
plt.rcParams['axes.unicode_minus']=False  #设置中文显示

for i in range(1,25):
    t.append(sum(feigong['hour']==i)/len(feigong['hour']))
plt.plot(range(1,25),t,'g-',label='非工作日')
plt.xticks(range(1,25))
tt=[]
for i in range(1,25):
    tt.append(sum(gongzuori['hour']==i)/len(gongzuori['hour']))
plt.plot(range(1,25),tt,'b-',label='工作日')
plt.xticks(range(1,25))
plt.legend()
plt.title('食堂就餐时间曲线图')
plt.savefig('就餐峰值.jpg')
#横轴是时间分布，纵轴是时间占比

