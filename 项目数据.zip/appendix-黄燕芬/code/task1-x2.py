
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
data1= pd.read_table("task1-X1.csv", sep = ',',encoding = 'gbk')
data2= pd.read_table("task1-X2.csv", sep = ',',encoding = 'gbk')
data= pd.merge(data1, data2,on = 'CardNo')#主键合并两个数据框
data.drop(['Unnamed: 0_x','Index_x'], axis=1, inplace=True)#删除多于列
data.to_csv('task1_1_X.csv',encoding='gbk')
data.head()

