
# coding: utf-8

# In[2]:


import pandas as pd 
import numpy as np
data= pd.read_table("C:\\Users\\if\\Desktop\\task1_1-X.csv", sep = ',',encoding = 'gbk')#读取数据
# print(data['CardNo'].count())import pandas as pd 
data2=data.duplicated('CardNo')   #除去id重复的数据
total=data['CardNo'].count()-sum(data2)#原始数据减去id重复的算出总人数
#print(total)
mean=sum(data['Money'])/total #计算人均消费
print('本月人均消费',mean)
xiaofei=data['CardNo'].value_counts().values
xiaofei=sum(xiaofei)/total#计算人均刷卡频次
print('本月人均刷卡频次',round(xiaofei))

