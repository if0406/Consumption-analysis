
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
data= pd.read_table("D:\T\data1.csv", sep = ',',encoding = 'gbk')#读取数据
#print(data)
data.dtypes     #查看数据类型
data.describe()  ##查看数据描述统计信息
data=data.drop_duplicates(subset=['CardNo']) #查看学生卡号数据重复值并去重
data=data.drop_duplicates(subset=['AccessCardNo']) #查看学生门禁卡号数据重复值并去重
data.to_csv('task1-X1.csv',encoding='gbk')
data.head()


# In[2]:


import numpy as np
import pandas as pd
data= pd.read_table("D:\T\data2.csv", sep = ',',encoding = 'gbk')
data['Date'] = pd.to_datetime(data['Date'],infer_datetime_format=True)#把时间格式标准化
data['hour']=data['Date'].dt.hour  #提取时间中的小时作为新增列
data.dtypes     #查看数据类型
data.describe()  ##查看数据描述统计信息
##统计各个特征的缺失率
naRate = (data.isnull().sum()/ data.shape[0]*100).astype('str')+'%'
print('data每个特征缺失的率为：\n',naRate)
#删除缺失率过高的两列
data.drop(['TermSerNo','conOperNo'], axis=1, inplace=True)
#查看学生校园卡号和校园卡编号不一一对应的数据并去除
data1=data.drop_duplicates(subset=['CardNo','PeoNo'],keep=False,inplace=False) 
data=data.drop(data1.index)
#查看是否存在消费为负值的异常值
data1=data[data['Type'].isin(['消费'])]
col1=data1['Money']
col1[np.abs(col1)<=0]
#查看是否存在存款为负值或0的异常值
data2=data[data['Type'].str.contains('存款')]
col2=data2['FundMoney']
col2[np.abs(col2)<=0]
#选取存款为0的行并删除
data2=data2[data2['FundMoney'].isin([0])]#选取包含数字0的行
data=data.drop(data2.index)
#查看是否存在取款为负值或0的异常值
data3=data[data['Type'].str.contains('取款')]
col3=data3['Money']
col3[np.abs(col3)<=0]
#查看是否存在退款为负值或0的异常值
data4=data[data['Type'].str.contains('退款')]
col4=data4['FundMoney']
col4[np.abs(col4)<=0]
#选取退款为0的行并删除
data4=data4[data4['FundMoney'].isin([0])]#选取包含数字0的行
data=data.drop(data4.index)
#查看食堂非营业期有消费记录的异常值(定义食堂12点关门)
data5=data[data['Dept'].str.contains('食堂')]
data5=data5[data5['hour']<=5]
data=data.drop(data5.index)
data.to_csv('task1-X2.csv',encoding='gbk')
data.head()

