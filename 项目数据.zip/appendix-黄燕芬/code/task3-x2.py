
# coding: utf-8

# In[3]:


import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
data= pd.read_table("C:\\Users\\if\\Desktop\\task1_1-X.csv", sep = ',',encoding = 'gbk')#读取数据
major=data[data['Major']=='18审计']
man=major[major['Sex']=='男']
woman=major[major['Sex']=='女']

dupe=man.duplicated('CardNo')
total=man['CardNo'].count()-sum(dupe)
total
mean=sum(man['Money'])/total #人均消费
print('18审计男生人均消费',mean)

dupe=woman.duplicated('CardNo')
total=woman['CardNo'].count()-sum(dupe)
total
mean1=sum(woman['Money'])/total #人均消费
print('18审计女生人均消费',mean1)

l1=['男','女']
l2=[mean,mean1]
s1=pd.Series(l2,index=l1)
plt.rcParams['font.sans-serif']=['SimHei']
s1.plot.bar(x=l1,y=l2)
plt.title('18审计专业不同性别消费对比图')
plt.savefig('18审计专业不同性别消费对比图.jpg')

