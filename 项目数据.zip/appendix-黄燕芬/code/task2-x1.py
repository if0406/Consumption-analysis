
# coding: utf-8

# In[6]:


import numpy as np
import pandas as pd
data= pd.read_table("D:\\T\\task1-X2.csv", sep = ',',encoding = 'gbk')
data['Date'] = pd.to_datetime(data['Date'],infer_datetime_format=True)#将日期的格式转为标准模式
data['year']=data['Date'].dt.year   #提取时间中的年作为新增列
data['month']=data['Date'].dt.month   #提取时间中的月作为新增列
data['day']=data['Date'].dt.day     #提取时间中的日作为新增列
data=data[data['Dept'].str.contains('食堂')]#提取食堂的记录
frame = pd.DataFrame(data, columns = [ 'hour', 'CardNo', 'Dept','year', 'month', 'day']) #提取学生卡号，日期和食堂生成新的表格
def function(a, b): 
    if '食堂' in a and (b > 6 and b < 9 ): 
        return  '早餐'
    elif '食堂' in a and (b > 11 and b < 14 ):
        return "午餐"
    elif '食堂' in a and (b > 17 and b < 20 ):
        return "晚餐"
    else:
        return '其他'
#print(frame, '\n') 
frame['contime'] = frame.apply(lambda x: function(x.Dept, x.hour), axis = 1) #自定义函数把食堂的消费记录分为早中晚和其他
#print(frame)
frame1=frame[frame['contime'].isin(['其他'])]
frame=frame.drop(frame1.index)#选取其他就餐时间的行并删除
#print(frame)
frame.drop_duplicates(subset=['CardNo',"contime",'year', 'month', 'day'],keep="first",inplace=True) #把时间接近的消费记录作为一次就餐人次
frame.to_csv('task2-X1.csv',encoding='gbk')
total=len(frame)#统计所有食堂的总的就餐人次
a=frame[frame['Dept'].isin(["第一食堂"])]
a=len(a)     
A=a/total     #统计第一食堂的就餐人数和占比
#print('第一食堂的就餐人次为;',len(a))
b=frame[frame['Dept'].isin(["第二食堂"])]
b=len(b)
B=b/total     #统计第二食堂的就餐人数和占比
#print('第二食堂的就餐人次为;',len(b))
c=frame[frame['Dept'].isin(["第三食堂"])]
c=len(c)
C=c/total     #统计第三食堂的就餐人数和占比
#print('第三食堂的就餐人次为;',len(c))
d=frame[frame['Dept'].isin(["第四食堂"])]
d=len(d)
D=d/total      #统计第四食堂的就餐人数和占比
#print('第四食堂的就餐人次为;',len(d))
e=frame[frame['Dept'].isin(["第五食堂"])]
e=len(e)
E=e/total       #统计第五食堂的就餐人数和占比
#print('第五食堂的就餐人次为;',len(e))
f=frame[frame['Dept'].isin(["教师食堂"])]
f=len(f)
F=f/total      #统计教师食堂的就餐人数和占比
#print('教师食堂的就餐人次为;',len(f))
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(6,6))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=A,B,C,D,E,F
labels='第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'
plt.title('各个食堂就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#绘制各个食堂就餐人次占比饼图


# In[2]:


frame= pd.read_table("task2-X1.csv", sep = ',',encoding = 'gbk')#读取数据
a=frame[frame['Dept'].isin(["第一食堂"])]#提取第一食堂数据
a1=a[a['contime'].str.contains('早餐')] 
a2=a[a['contime'].str.contains('午餐')]
a3=a[a['contime'].str.contains('晚餐')]
a=len(a)
a1=len(a1)
a2=len(a2)
a3=len(a3)
A1=a1/a
A2=a2/a
A3=a3/a  #计算第一食堂早中晚餐就餐人数占比并画图
#print("第一食堂早中晚餐就餐人数分别为",len(a1),len(a2),len(a3))
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=A1,A2,A3
labels='早餐','午餐','晚餐'
plt.title('第一食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#第二食堂
b=frame[frame['Dept'].isin(["第二食堂"])]
b1=b[b['contime'].str.contains('早餐')] 
b2=b[b['contime'].str.contains('午餐')]
b3=b[b['contime'].str.contains('晚餐')]
b=len(b)
b1=len(b1)
b2=len(b2)
b3=len(b3)
B1=b1/b
B2=b2/b
B3=b3/b
#print("第二食堂早中晚餐就餐人数分别为",len(b1),len(b2),len(b3))
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=B1,B2,B3
labels='早餐','午餐','晚餐'
plt.title('第二食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#第三食堂
c=frame[frame['Dept'].isin(["第三食堂"])]
c1=c[c['contime'].str.contains('早餐')] 
c2=c[c['contime'].str.contains('午餐')]
c3=c[c['contime'].str.contains('晚餐')]
c=len(c)
c1=len(c1)
c2=len(c2)
c3=len(c3)
C1=c1/c
C2=c2/c
C3=c3/c
#print("第一食堂早中晚餐就餐人数分别为",len(c1),len(c2),len(c3))
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=C1,C2,C3
labels='早餐','午餐','晚餐'
plt.title('第三食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#第四食堂
d=frame[frame['Dept'].isin(["第四食堂"])]
d1=d[d['contime'].str.contains('早餐')] 
d2=d[d['contime'].str.contains('午餐')]
d3=d[d['contime'].str.contains('晚餐')]
#print("第四食堂早中晚餐就餐人数分别为",len(d1),len(d2),len(d3))
d=len(d)
d1=len(d1)
d2=len(d2)
d3=len(d3)
D1=d1/d
D2=d2/d
D3=d3/d
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=D1,D2,D3
labels='早餐','午餐','晚餐'
plt.title('第四食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#第五食堂
e=frame[frame['Dept'].isin(["第五食堂"])]
e1=e[e['contime'].str.contains('早餐')] 
e2=e[e['contime'].str.contains('午餐')]
e3=e[e['contime'].str.contains('晚餐')]
#print("第四食堂早中晚餐就餐人数分别为",len(e1),len(e2),len(e3))
e=len(e)
e1=len(e1)
e2=len(e2)
e3=len(e3)
E1=e1/e
E2=e2/e
E3=e3/e
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=E1,E2,E3
labels='早餐','午餐','晚餐'
plt.title('第五食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()
#教师食堂
f=frame[frame['Dept'].isin(["教师食堂"])]
f1=f[f['contime'].str.contains('早餐')] 
f2=f[f['contime'].str.contains('午餐')]
f3=f[f['contime'].str.contains('晚餐')]
#print("第四食堂早中晚餐就餐人数分别为",len(f1),len(f2),len(f3))
f=len(f)
f1=len(f1)
f2=len(f2)
f3=len(f3)
F1=f1/f
F2=f2/f
F3=f3/f
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['早餐','午餐','晚餐']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=F1,F2,F3
labels='早餐','午餐','晚餐'
plt.title('教师食堂早中晚就餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
# plt.axis('equal')
plt.savefig('D:\T')
plt.show()


# In[7]:


zaocan=a1+b1+c1+d1+e1+f1  #统计所有食堂早餐就餐人数且各个食堂早餐占比
A1=a1/zaocan
B1=b1/zaocan
C1=c1/zaocan
D1=d1/zaocan
E1=e1/zaocan
F1=f1/zaocan
wucan=a2+b2+c2+d2+e2+f2  #统计所有食堂午餐就餐人数且各个食堂早餐占比
A2=a2/wucan
B2=b2/wucan
C2=c2/wucan
D2=d2/wucan
E2=e2/wucan
F2=f2/wucan
wancan=a3+b3+c3+d3+e3+f3   #统计所有食堂晚餐就餐人数且各个食堂早餐占比
A3=a3/wancan
B3=b3/wancan
C3=c3/wancan
D3=d3/wancan
E3=e3/wancan
F3=f3/wancan
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False## 设置中文显示
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x=A1,B1,C1,D1,E1,F1
labels='第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'
plt.title('所有食堂早餐人次占比饼图')
plt.pie(x,labels=labels,autopct='%1.1f%%')
plt.savefig('所有食堂早餐占比.jpg')
plt.show()      ##绘制所有食堂早餐人数占比饼图
 
plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x2=A2,B2,C2,D2,E2,F2
labels='第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'
plt.title('所有食堂午餐人次占比饼图')
plt.pie(x2,labels=labels,autopct='%1.1f%%')
plt.savefig('所有食堂午餐占比.jpg')
plt.show()    ##绘制所有食堂午餐人数占比饼图

plt.figure(figsize=(4,4))## 将画布设定为正方形，则绘制的饼图是正圆
label= ['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']## 定义饼状图的标签，标签是列表
explode = [0.01, 0.01, 0.01]## 设定各项离心n个半径
x3=A3,B3,C3,D3,E3,F3
labels='第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'
plt.title('所有食堂晚餐人次占比饼图')
plt.pie(x3,labels=labels,autopct='%1.1f%%')
plt.savefig('所有食堂晚餐占比.jpg')
plt.show()  ##绘制所有食堂晚餐人数占比饼图

